/* $OpenBSD: version.h,v 1.81 2018/03/24 19:29:03 markus Exp $ */

#define SSH_VERSION	"OpenSSH_7.7"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
